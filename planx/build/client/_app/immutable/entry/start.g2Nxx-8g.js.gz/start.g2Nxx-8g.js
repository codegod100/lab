import{l as o,a as r}from"../chunks/BMx6HN0F.js";export{o as load_css,r as start};
